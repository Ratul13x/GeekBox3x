from flask import Flask, render_template, redirect, url_for, flash, request, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from models import db, User, Product, Showcase, ChatMessage, Meetup
from forms import RegisterForm, LoginForm, ProductForm, ShowcaseForm, MeetupForm, ProductEditForm
from werkzeug.utils import secure_filename
from datetime import datetime
from flask import send_from_directory
from flask_socketio import SocketIO, join_room, leave_room, send

import os

# db = SQLAlchemy()


app = Flask(__name__)
app.config.from_object('config.Config')

db.init_app(app)
socketio = SocketIO(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"  # type: ignore[attr-defined]

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        new_user = User()
        new_user.username = form.username.data
        new_user.role = form.role.data
        new_user.email = form.email.data
        new_user.set_password(form.password.data)
        db.session.add(new_user)
        db.session.commit()
        flash("Registered successfully!", "success")
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid credentials.', 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/products', methods=['GET'])
def products():
    search_query = request.args.get('search', '')
    user_filter = request.args.get('filter_user', '')
    category_filter = request.args.get('filter_category', '')
    sort = request.args.get('sort', '')

    query = Product.query

    if search_query:
        query = query.filter(
            Product.name.ilike(f'%{search_query}%') |
            Product.description.ilike(f'%{search_query}%')
        )

    if user_filter:
        query = query.filter(Product.recommended_for.like(f'%{user_filter}%'))

    if category_filter:
        query = query.filter_by(category=category_filter)

    # Sorting
    if sort == 'price_asc':
        query = query.order_by(Product.price.asc())
    elif sort == 'price_desc':
        query = query.order_by(Product.price.desc())
    elif sort == 'date_asc':
        query = query.order_by(Product.id.asc())
    elif sort == 'date_desc':
        query = query.order_by(Product.id.desc())

    items = query.all()

    return render_template(
        'products.html',
        products=items,
        search_query=search_query,
        user_filter=user_filter,
        category_filter=category_filter
    )



@app.route('/add-products', methods=['GET', 'POST'])
@login_required
def add_products():
    if current_user.role != 'admin':
        flash("Admins only!", "danger")
        return redirect(url_for('index'))
    form = ProductForm()
    if form.validate_on_submit():
        filename = None
        if form.image.data:
            filename = secure_filename(form.image.data.filename)
            upload_dir = os.path.join(app.root_path, 'static', 'uploads')
            os.makedirs(upload_dir, exist_ok=True)
            form.image.data.save(os.path.join(upload_dir, filename))
        new_product = Product()
        new_product.name = form.name.data
        new_product.category = form.category.data
        new_product.recommended_for = ",".join(form.recommended_for.data) if form.recommended_for.data else None
        new_product.description = form.description.data
        new_product.price = form.price.data
        new_product.image_filename = filename
        db.session.add(new_product)
        db.session.commit()
        flash("Product added.", "success")
        return redirect(url_for('products'))
    return render_template('add_products.html', form=form)

@app.route('/edit-product/<int:product_id>', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    if current_user.role != 'admin':
        flash('Admins only!', 'danger')
        return redirect(url_for('products'))
    product = Product.query.get_or_404(product_id)
    form = ProductEditForm(obj=product)
    if request.method == 'POST' and form.validate_on_submit():
        # If price is changed, update previous_price
        if form.price.data != product.price:
            product.previous_price = product.price
        product.name = form.name.data
        product.category = form.category.data
        product.recommended_for = ",".join(form.recommended_for.data) if form.recommended_for.data else None
        product.description = form.description.data
        product.price = form.price.data
        if form.image.data:
            filename = secure_filename(form.image.data.filename)
            upload_dir = os.path.join(app.root_path, 'static', 'uploads')
            os.makedirs(upload_dir, exist_ok=True)
            form.image.data.save(os.path.join(upload_dir, filename))
            product.image_filename = filename
        db.session.commit()
        flash('Product updated.', 'success')
        return redirect(url_for('products'))
    # Pre-fill previous_price for the form
    form.previous_price.data = product.previous_price
    return render_template('add_products.html', form=form, product=product, legend_label='Edit Product', submit_label='Update Product')

@app.route('/delete-product/<int:product_id>', methods=['GET'])
@login_required
def delete_product(product_id):
    if current_user.role != 'admin':
        flash('Admins only!', 'danger')
        return redirect(url_for('products'))
    product = Product.query.get_or_404(product_id)
    # Remove image file if exists
    if product.image_filename:
        image_path = os.path.join('static', 'uploads', product.image_filename)
        if os.path.exists(image_path):
            os.remove(image_path)
    db.session.delete(product)
    db.session.commit()
    flash('Product deleted.', 'success')
    return redirect(url_for('products'))

@app.route('/pc-builders')
def pc_builders():
    return render_template('pc_builders.html')

@app.route('/audiophiles')
def audiophiles():
    return render_template('audiophiles.html')

@app.route('/keyboards')
def keyboards():
    return render_template('keyboards.html')

@app.route('/smart-home')
def smart_home():
    return render_template('smart_home.html')

@app.route('/showcase')
def showcase():
    showcases = Showcase.query.order_by(Showcase.created_at.desc()).all()
    return render_template('showcase.html', showcases=showcases)


@app.route('/create-showcase', methods=['GET', 'POST'])
@login_required
def create_showcase():
    form = ShowcaseForm()
    if form.validate_on_submit():
        image_filenames = []
        allowed_extensions = {"png", "jpg", "jpeg", "gif"}
        if form.images.data:
            upload_dir = os.path.join(app.root_path, 'static', 'uploads')
            os.makedirs(upload_dir, exist_ok=True)
            for img in form.images.data:
                if img and img.filename:
                    filename = secure_filename(img.filename)
                    ext = filename.rsplit('.', 1)[-1].lower()
                    if ext in allowed_extensions:
                        save_path = os.path.join(upload_dir, filename)
                        img.save(save_path)
                        image_filenames.append(filename)
        if not image_filenames:
            flash('No valid image uploaded. Please select a PNG, JPG, JPEG, or GIF file.', 'danger')
            return render_template('create_showcase.html', form=form)

        new_showcase = Showcase()
        new_showcase.title = form.title.data
        new_showcase.category = ",".join(form.category.data) if form.category.data else None
        new_showcase.components = form.components.data
        new_showcase.image_filenames = ",".join(image_filenames)
        new_showcase.user_id = current_user.id
        db.session.add(new_showcase)
        db.session.commit()
        flash('Showcase created successfully!', 'success')
        return redirect(url_for('showcase'))
    return render_template('create_showcase.html', form=form)

@app.route('/chat/<category>')
@login_required
def chat(category):
    allowed_categories = ['PC', 'Audio', 'Keyboard', 'SmartHome']
    if category not in allowed_categories:
        flash('Invalid chat room', 'danger')
        return redirect(url_for('index'))

    # Load last 50 messages for the category
    messages = ChatMessage.query.filter_by(category=category).order_by(ChatMessage.timestamp.asc()).limit(50).all()

    return render_template('chat.html', category=category, messages=messages)

@socketio.on('join_room')
def handle_join(data):
    room = data['room']
    join_room(room)
    msg = {'user': 'System', 'message': f'{current_user.username} has joined the room.'}
    socketio.emit('message', msg, room=room)  # type: ignore

@socketio.on('leave_room')
def handle_leave(data):
    room = data['room']
    leave_room(room)
    msg = {'user': 'System', 'message': f'{current_user.username} has left the room.'}
    socketio.emit('message', msg, room=room)  # type: ignore

@socketio.on('send_message')
def handle_message(data):
    room = data['room']
    message = data['message']

    # Save to database
    chat_msg = ChatMessage()
    chat_msg.user_id = current_user.id
    chat_msg.username = current_user.username
    chat_msg.category = room
    chat_msg.message = message
    db.session.add(chat_msg)
    db.session.commit()

    # Broadcast to the room
    msg = {'user': current_user.username, 'message': message}
    socketio.emit('message', msg, room=room)  # type: ignore

@app.route('/showcase/<int:showcase_id>')
def showcase_detail(showcase_id):
    showcase = Showcase.query.get_or_404(showcase_id)
    images = showcase.image_filenames.split(',') if showcase.image_filenames else []
    is_admin = current_user.is_authenticated and current_user.role == 'admin'
    return render_template('showcase_detail.html', showcase=showcase, images=images, is_admin=is_admin)
# Delete showcase route
@app.route('/delete-showcase/<int:showcase_id>', methods=['POST'])
@login_required
def delete_showcase(showcase_id):
    if current_user.role != 'admin':
        flash('Admins only!', 'danger')
        return redirect(url_for('showcase_detail', showcase_id=showcase_id))
    showcase = Showcase.query.get_or_404(showcase_id)
    # Remove images
    if showcase.image_filenames:
        for filename in showcase.image_filenames.split(','):
            if filename.strip():
                image_path = os.path.join(app.root_path, 'static', 'uploads', filename)
                if os.path.exists(image_path):
                    os.remove(image_path)
    db.session.delete(showcase)
    db.session.commit()
    flash('Showcase deleted.', 'success')
    return redirect(url_for('showcase'))

# Update showcase route
@app.route('/edit-showcase/<int:showcase_id>', methods=['GET', 'POST'])
@login_required
def edit_showcase(showcase_id):
    if current_user.role != 'admin':
        flash('Admins only!', 'danger')
        return redirect(url_for('showcase_detail', showcase_id=showcase_id))
    showcase = Showcase.query.get_or_404(showcase_id)
    form = ShowcaseForm(obj=showcase)
    if request.method == 'POST' and form.validate_on_submit():
        image_filenames = []
        allowed_extensions = {"png", "jpg", "jpeg", "gif"}
        if form.images.data:
            upload_dir = os.path.join(app.root_path, 'static', 'uploads')
            os.makedirs(upload_dir, exist_ok=True)
            for img in form.images.data:
                if img and img.filename:
                    filename = secure_filename(img.filename)
                    ext = filename.rsplit('.', 1)[-1].lower()
                    if ext in allowed_extensions:
                        save_path = os.path.join(upload_dir, filename)
                        img.save(save_path)
                        image_filenames.append(filename)
        # If new images uploaded, replace old ones
        if image_filenames:
            # Remove old images
            if showcase.image_filenames:
                for filename in showcase.image_filenames.split(','):
                    if filename.strip():
                        image_path = os.path.join(app.root_path, 'static', 'uploads', filename)
                        if os.path.exists(image_path):
                            os.remove(image_path)
            showcase.image_filenames = ",".join(image_filenames)
        showcase.title = form.title.data
        showcase.category = ",".join(form.category.data) if form.category.data else None
        showcase.components = form.components.data
        db.session.commit()
        flash('Showcase updated.', 'success')
        return redirect(url_for('showcase_detail', showcase_id=showcase_id))
    # Pre-fill form with existing images (not shown in upload field)
    return render_template('create_showcase.html', form=form, showcase=showcase, legend_label='Edit Showcase', submit_label='Update Showcase')

@app.route('/meet')
def meet():
    meetups = Meetup.query.order_by(Meetup.date.desc()).all()
    return render_template('meet.html', meetups=meetups)

@app.route('/announce-meetup', methods=['GET', 'POST'])
@login_required
def announce_meetup():
    if current_user.role != 'admin':
        flash('Admins only!', 'danger')
        return redirect(url_for('meet'))
    form = MeetupForm()
    if form.validate_on_submit():
        meetup = Meetup()
        meetup.title = form.title.data
        meetup.community = form.community.data
        meetup.description = form.description.data
        meetup.date = form.date.data
        meetup.location = form.location.data
        meetup.created_by = current_user.id
        db.session.add(meetup)
        db.session.commit()
        flash('Meetup announced!', 'success')
        return redirect(url_for('meet'))
    return render_template('add_meetup.html', form=form)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    socketio.run(app, '0.0.0.0', debug=True)